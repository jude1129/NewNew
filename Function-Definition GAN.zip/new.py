import ollama 

def ask_model_for_text(model_name, user_prompt):
    print(f"{model_name}")
    print(f"Prompt: {prompt}")
    try:
        response = ollama.chat(model=model_name,messages=[{'role':'user','content':user_prompt}],options={'temprature':0.0})
        content = response['message']['content']
        print(f"{content}")
    except Exception as e:
        print(f"Error {e}")
if __name__ == "__main__":
    modelname = "qwen:0.5b"
    prompt = "Explain the theory of relativity in simple terms."
    ask_model_for_text(modelname, prompt)           
